import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient

app = Flask(__name__)
CORS(app)

# --- MONGODB CONFIGURATION ---
# Ensure MongoDB is running!
MONGO_URI = "mongodb://localhost:27017/"
try:
    client = MongoClient(MONGO_URI)
    db = client['battery_ai_db']
    users_collection = db['users']
    history_collection = db['chat_history']
    sessions_collection = db['sessions'] # Stores Chat Titles
    print("✅ MongoDB Connected Successfully")
except Exception as e:
    print(f"❌ MongoDB Error: {e}")

BATTERY_KEYWORDS = [
    'battery', 'charge', 'voltage', 'current', 'lithium', 'ion', 
    'power', 'energy', 'cell', 'anode', 'cathode', 'electrolyte', 
    'bms', 'cycle', 'capacity', 'mah', 'wh', 'volt', 'ampere', 'hi', 'hello', 'help'
]

# --- AUTH ---
@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    if users_collection.find_one({"username": username}):
        return jsonify({"error": "Username taken"}), 400
    users_collection.insert_one({"username": username, "password": password, "created_at": datetime.datetime.utcnow()})
    return jsonify({"success": True})

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    user = users_collection.find_one({"username": username})
    if user and user['password'] == password:
        return jsonify({"success": True, "username": username})
    else:
        return jsonify({"error": "Invalid Credentials"}), 401

# --- CHAT & SESSION SAVING (CRITICAL FIX) ---
@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    user_query = data.get('query', '')
    username = data.get('username')
    file_name = data.get('file', '')
    session_id = data.get('session_id') 

    # 1. Generate AI Response
    user_query_lower = user_query.lower()
    if not any(word in user_query_lower for word in BATTERY_KEYWORDS):
        ai_response = "I can't answer that. I am strictly programmed to assist with Battery Technology only."
    else:
        ai_response = f"Analysis of '{user_query}' completed. Systems nominal. Battery parameters optimized."

    timestamp = datetime.datetime.utcnow()

    # 2. Save Message to History
    if username and session_id:
        history_collection.insert_one({
            "session_id": session_id,
            "username": username,
            "user_query": user_query,
            "ai_response": ai_response,
            "file": file_name,
            "timestamp": timestamp
        })

        # 3. Save/Update Session Metadata (For Sidebar)
        existing_session = sessions_collection.find_one({"session_id": session_id})
        
        if not existing_session:
            # New Chat: Use query as title
            title_preview = user_query[:30] + "..." if len(user_query) > 30 else user_query
            sessions_collection.insert_one({
                "session_id": session_id,
                "username": username,
                "title": title_preview,
                "last_active": timestamp
            })
        else:
            # Existing Chat: Update time
            sessions_collection.update_one(
                {"session_id": session_id},
                {"$set": {"last_active": timestamp}}
            )

    return jsonify({"response": ai_response})

# --- HISTORY RETRIEVAL ---
@app.route('/api/sessions', methods=['GET'])
def get_sessions():
    username = request.args.get('username')
    if not username: return jsonify([])
    
    # Return list of chat sessions
    sessions = list(sessions_collection.find({"username": username}, {'_id': 0}).sort("last_active", -1))
    return jsonify(sessions)

@app.route('/api/session/<session_id>', methods=['GET'])
def get_session_chat(session_id):
    # Return messages for a specific session
    messages = list(history_collection.find({"session_id": session_id}, {'_id': 0}).sort("timestamp", 1))
    return jsonify(messages)

@app.route('/api/session/rename', methods=['POST'])
def rename_session():
    data = request.json
    session_id = data.get('session_id')
    new_title = data.get('title')
    sessions_collection.update_one({"session_id": session_id}, {"$set": {"title": new_title}})
    return jsonify({"success": True})

if __name__ == '__main__':
    print("🔋 Battery AI Backend Running...")
    app.run(debug=True, port=5000)
    